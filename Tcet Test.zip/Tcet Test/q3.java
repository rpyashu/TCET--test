//Write a Java program to count the frequency of each word in a string using HashMap? Input: This is a test string. This string is for testing. Output:a : 1 testing.: 1 test: 1 string: 1 this: 2 for: 1 in: 2 string.: 1

import java.util.HashMap;
import java.util.Map;

public class q3 {
    public static void main(String[] args) {
        String input = "This is a test string.";

        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
