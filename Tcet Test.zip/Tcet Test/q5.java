//A warehouse is organizing crates of goods into a row. The crates represent an array of N number of integer values, where 0 indicates an empty crate. The task is to move all the empty crates to the end of the row, while maintaining the relative order of the non-empty crates. How can this be achieved?

public class q5 {
    public static void main(String[] args) {
        int[] crates = {0, 6, 0, 3, 15, 0, 0, 8, 0};
        moveZerosToEnd(crates);
        for (int crate = 0; crate < crates.length; crate++) {
            System.out.print(crates[crate] + " ");
        }
    }
    public static void moveZerosToEnd(int[] array) {
        int insertPosition = 0;
        for (int i = 0; i <= array.length; i++) { 
            if (array[i] != 0) {
                array[insertPosition] = array[i];
                insertPosition++;
            }
        }
        while (insertPosition <= array.length) {
            array[insertPosition] = 0;
            insertPosition++;
        }
    }
}

