//Write a java program to implement the functional interface called "Sayable" by using the lambda expression with an abstract method called "say" consisting of one String parameter and returning a greeting message?

@FunctionalInterface
interface Sayable {
    String say(String name);
}
public class q1 {
    public static void main(String[] args) {
        Sayable sayable = (name) -> "Hello, " + name + "welcome";
        String message = sayable.say("Alice");
        System.out.println(message);
    }
}